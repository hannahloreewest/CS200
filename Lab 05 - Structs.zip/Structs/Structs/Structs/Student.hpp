#pragma once
#ifndef _STUDENT_HPP
#define _STUDENT_HPP

#include <string>
using namespace std;

struct Student
{
	string name;
	string degree;
	double gpa;

};

#endif