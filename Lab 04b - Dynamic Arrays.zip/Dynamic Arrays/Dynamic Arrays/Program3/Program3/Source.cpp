#include <iostream>
#include <string>
using namespace std;


int main()
{

	string ears[3] = { "   ^ ^   ",   "  n   n ",     "  *   *  " };
	string heads[3] = { " ( o_o ) ",   " ( x_x )" ,    " ( >_< ) " };
	string bodies[3] = { "/(     )\\",  "\\(     )/",   "o(     )o" };
	string feet[3] = { "  d   b   ",  "  @   @ ",     "  () () " };

	string * ptrEars;
	string * ptrHead;
	string * ptrBody;
	string * ptrFeet;

	cout << "Enter ears (0-2): " << endl;
	cin >> ears[3];
	ptrEars = &ears[3];

	cout << "Enter head (0-2): " << endl;
	cin >> heads[3];
	ptrEars = &heads[3];

	cout << "Enter body (0-2): " << endl;
	cin >> bodies[3];
	ptrEars = &bodies[3];

	cout << "Enter feet (0-2): " << endl;
	cin >> feet[3];
	ptrEars = &feet[3];

	cout << endl << *ptrEars << endl << *ptrHead << endl << *ptrBody << endl << *ptrFeet << endl;


	return 0;
}