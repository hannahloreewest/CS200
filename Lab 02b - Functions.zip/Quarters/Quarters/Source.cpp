#include <iostream>
#include <string>
using namespace std;

float CountChange(int quarterCount, int dimeCount, int nickelCount, int pennyCount)// Declare function here
{
	float CountChange = (quarterCount * .25) + (dimeCount * .1) + (nickelCount * .05) + (pennyCount + .01);
	return CountChange;
}
int main()
{
	while (true)
	{
		int quarters, dimes, nickels, pennies;

		cout << "How many quarters? ";
		cin >> quarters;

		cout << "How many dimes? ";
		cin >> dimes;

		cout << "How many nickels? ";
		cin >> nickels;

		cout << "How many pennies? ";
		cin >> pennies;

		float money = CountChange(quarters, dimes, nickels, pennies);
		cout << "Money: $" << money << endl;

		cout << endl << endl;
	}

	return 0;
}